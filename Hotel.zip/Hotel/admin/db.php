<?php
$con = mysqli_connect("localhost","root","test","hotel") or die(mysql_error());

?>